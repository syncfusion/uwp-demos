Data for some of the map samples included is sourced from the  websites listed below. Terms and conditions for use are listed next to the source. Syncfusion is not responsible for the content/content license and makes absolutely no representations or warranties with regard to the same.

Website Link Terms and Conditions for use
http://www.naturalearthdata.com/downloads/  http://www.naturalearthdata.com/about/terms-of-use/

https://research.cip.cgiar.org/gis/index.php 	https://research.cip.cgiar.org/gis/index.php

http://www.nationalatlas.gov/atlasftp.html 	http://www.nationalatlas.gov/policies.html

http://downloads.cloudmade.com/ 	http://cloudmade.com/terms_conditions

